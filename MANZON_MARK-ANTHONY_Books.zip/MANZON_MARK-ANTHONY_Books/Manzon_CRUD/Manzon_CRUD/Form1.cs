﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Manzon_CRUD
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connection = "server=localhost;user id=root;password=;database=operation";
            MySqlConnection conn = new MySqlConnection(connection);
            string SELECT = "SELECT * FROM books WHERE BOOK_ID = " + int.Parse(txtID.Text);
            MySqlCommand cmd = new MySqlCommand(SELECT, conn);
            MySqlDataReader mdr;
            conn.Open();
            mdr = cmd.ExecuteReader();
            if (mdr.Read())
            {
                MessageBox.Show("Book Found");
                txtDesc.Text = mdr.GetString("DESCRIPTION");
                txtPubl.Text = mdr.GetString("PUBLISHER");
                txtAuth.Text = mdr.GetString("AUTHOR");
                txtShelv.Text = mdr.GetString("SHELVESNO");
            }
            else
            {
                MessageBox.Show("No Record Found");
                txtDesc.Text = "";
                txtPubl.Text = "";
                txtAuth.Text = "";
                txtID.Text = "";
                txtShelv.Text = "";
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connection = "server = localhost;user id = root; password=; database=operation";
            string query = "INSERT INTO books (BOOK_ID, DESCRIPTION, PUBLISHER, AUTHOR, SHELVESNO) VALUES ('" + txtID.Text + "','" + txtDesc.Text + "','" + txtPubl.Text + "','" + txtAuth.Text + "','" + txtShelv.Text + "')";
            MySqlConnection conn = new MySqlConnection(connection);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            MySqlDataReader dr;
            conn.Open();
            dr = cmd.ExecuteReader();
            MessageBox.Show("Successfully Inserted");
            txtAuth.Text = "";
            txtDesc.Text = "";
            txtID.Text = "";
            txtPubl.Text = "";
            txtShelv.Text = "";
            conn.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txtAuth.Enabled = true;
            txtDesc.Enabled = true;
            txtID.Enabled = true;
            txtPubl.Enabled = true;
            txtShelv.Enabled = true;
            MessageBox.Show("You can now add New Books");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string connection = "server = localhost;user id = root; password=; database=operation";
            string query = "UPDATE books SET DESCRIPTION = '" + txtDesc.Text + "', PUBLISHER = '" + txtPubl.Text + "', AUTHOR = '" + txtAuth.Text + "', SHELVESNO = '" + txtShelv.Text + "' WHERE BOOK_ID = '" + txtID.Text + "'";
            MySqlConnection conn = new MySqlConnection(connection);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            MySqlDataReader dr;
            conn.Open();
            dr = cmd.ExecuteReader();
            MessageBox.Show("Successfully Updated");
            txtAuth.Text = "";
            txtDesc.Text = "";
            txtID.Text = "";
            txtPubl.Text = "";
            txtShelv.Text = "";
            conn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string connection = "server = localhost;user id = root; password=; database=operation";
            string query = "DELETE FROM books WHERE BOOK_ID = '" + txtID.Text + "'";
            MySqlConnection conn = new MySqlConnection(connection);
            MySqlCommand cmd = new MySqlCommand(query, conn);
            MySqlDataReader dr;
            conn.Open();
            dr = cmd.ExecuteReader();
            MessageBox.Show("Successfully Deleted");
            txtAuth.Text = "";
            txtDesc.Text = "";
            txtID.Text = "";
            txtPubl.Text = "";
            txtShelv.Text = "";
            conn.Close();
        }
    }
}
